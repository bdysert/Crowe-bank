﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Crowe_API;

namespace Crowe_Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Program_Output output = new Program_Output();
            Assert.AreEqual(output.DisplayOutput("console"), "Hello World");
            Assert.AreEqual(output.DisplayOutput("html"), "<H1 Hello World />");
            Assert.AreEqual(output.DisplayOutput("database"), "Hello World");
        }
    }
}
