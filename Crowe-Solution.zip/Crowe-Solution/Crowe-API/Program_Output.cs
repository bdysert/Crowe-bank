﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crowe_API
{
    public interface IWriteOutput
    {
        string DisplayOutput(string dest);
    }

    public class Program_Output : IWriteOutput
    {
        public string DisplayOutput(string dest)
        {
            switch (dest.ToLower())
            {
                case "console":
                    return "Hello World";
                case "html":
                    return "<H1 Hello World />";
                default:
                    return "Hello World";
            }
        }
    }
}
