﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Crowe_API;

namespace Crowe_Main
{
    public class Program
    {
        static void Main(string[] args)
        {
            string dest = ConfigurationManager.AppSettings["destination"].ToString().ToLower();
            Program_Output output = new Program_Output();
            Console.WriteLine(output.DisplayOutput(dest));
        }
    }
}
